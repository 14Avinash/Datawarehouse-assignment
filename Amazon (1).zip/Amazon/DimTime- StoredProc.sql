USE AmazonDWRN
GO

/***************************************************************
Create Date: Apr 25, 2014

***************************************************************/
IF Exists (select name from sys.procedures where name = 'GenerateDimTime')
	drop proc generateDimTime
Go

  
create proc GenerateDimTime  
(  
 --Input parameters: Start Date and End Date    
 @startdate datetime  ='2012-06-01',  
 @enddate   datetime  ='2020-12-31'  
   
)  
As  
Begin --Start of Sp  
Declare @dk int,  
  @yn int,@smn int,  
  @Qn int,  
  @mno int,  
  @wkn int,  
  @dn int,  
  @mn varchar(10),  
  @Tmn Varchar (20)  
    
  
set @yn=DATEPART(YY,@startdate)  
set @Qn=DATEPART(QQ,@startdate)  
set @smn=(select case when @Qn > 2 then 2 else 1 end )  
set @mno=DATEPART(MM,@startdate)  
set @wkn=DATEPART(WW,@startdate)  
set @dn=DATEPART(DD,@startdate)  
set @mn=DATENAME(MM,@startdate)  
set @Tmn=(select case when @mno=1 then 'Pausha'  
                      when @mno=2 then 'Magha'  
                      when @mno=3 then 'Phalguna'  
                      when @mno=4 then 'Chaitra'  
                      when @mno=5 then 'Vaisakha'  
                      when @mno=6 then 'Jyeshta'  
                      when @mno=7 then 'Ashada'  
                      when @mno=8 then 'Shraavana'  
                      when @mno=9 then 'Bhadrapada'  
                      when @mno=10 then 'Ashwina'  
                      when @mno=11 then 'Karthika'  
                   Else 'Marghasira'  
                   End)  
  
--  
while (@startdate<=@enddate)  
 Begin   
  set @dk=(Select CONVERT (char(8),@startdate,112))  
    
	--insert into DimTime
	 Insert into DimTimeRN values (@dk,@startdate,@yn,@smn,@Qn,@mno,@wkn,@dn,@mn,@Tmn)       
     set @startdate=@startdate+1  
     set @yn=DATEPART(YY,@startdate)       
  set @Qn=DATEPART(QQ,@startdate)  
  set @smn=(select case when @Qn > 2 then 2 else 1 end )  
  set @mno=DATEPART(MM,@startdate)  
  set @wkn=DATEPART(WW,@startdate)      
  set @dn=DATEPART(DD,@startdate)  
  set @mn=DATENAME(MM,@startdate)  
  set @Tmn=(select case when @mno=1 then 'Pausha'  
                      when @mno=2 then 'Magha'  
                      when @mno=3 then 'Phalguna'  
                      when @mno=4 then 'Chaitra'  
                      when @mno=5 then 'Vaisakha'  
                      when @mno=6 then 'Jyeshta'  
                      when @mno=7 then 'Ashada'  
                      when @mno=8 then 'Shraavana'  
                      when @mno=9 then 'Bhadrapada'  
                      when @mno=10 then 'Ashwina'  
                      when @mno=11 then 'Karthika'  
                   Else 'Marghasira'  
                   End)  
  
 End       
End   --End of Sp