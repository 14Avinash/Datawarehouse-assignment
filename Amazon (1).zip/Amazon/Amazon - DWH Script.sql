--DWH
use master
go

create database AmazonDW
go

USE AmazonDW
go


--Dim Table
create table DimProduct
(
	ProductKey		int				primary key,
	ProductName		varchar(40)		not null,
	ProductPrice	money			not null,
	CategoryName	varchar(50)		not null

)
go

select *  from DimProduct
go

--Dim Table
create table DimCustomer
(
	CustomerKey		int				primary key,
	CustomerName	varchar(40)		not null
	
)
go


select * from DimCustomer 
go


--Create Location Table
CREATE  TABLE DimLocation
(
	LocationKey	INT				PRIMARY KEY,
	Country		varchar(50)		NOT NULL,
	State		varchar(30)		NOT NULL,	
	City		varchar(200)		NOT NULL
)
GO


INSERT INTO DimLocation  VALUES (101, 'India', 'Telangana', 'Hyderabad')
INSERT INTO DimLocation  VALUES (102, 'India', 'Andhara Pradesh', 'Vizag')
INSERT INTO DimLocation  VALUES (103, 'India', 'Andhara Pradesh', 'Vijayawada')
INSERT INTO DimLocation  VALUES (104, 'India', 'Karnataka', 'Mysore')
INSERT INTO DimLocation  VALUES (105, 'India', 'Karnataka', 'Bangalore')
INSERT INTO DimLocation  VALUES (106, 'India', 'Tamilnadu', 'Chennai')
INSERT INTO DimLocation  VALUES (107, 'India', 'Tamilnadu', 'Ooty')

INSERT INTO DimLocation  VALUES (108, 'USA',  'Maryland', 'Baltimore')
INSERT INTO DimLocation  VALUES (109, 'USA', 'Texas', 'Dayton')
INSERT INTO DimLocation  VALUES (110, 'USA', 'Rhode Island', 'Providence')

INSERT INTO DimLocation  VALUES (111, 'USA', 'New Jersey','Chatham')
INSERT INTO DimLocation  VALUES (112, 'USA', 'New Jersey','Newark')
INSERT INTO DimLocation  VALUES (113, 'USA', 'New Jersey','Trenton')

INSERT INTO DimLocation  VALUES (114, 'USA', 'Maryland', 'Towson')
INSERT INTO DimLocation  VALUES (115, 'USA', 'Maryland', 'Parkville')
INSERT INTO DimLocation  VALUES (116, 'USA', 'Texas','Dallas')
INSERT INTO DimLocation  VALUES (117, 'USA', 'Texas', 'Houston')

INSERT INTO DimLocation  VALUES (118, 'USA', 'Rhode Island', 'Newport')
INSERT INTO DimLocation  VALUES (119, 'USA', 'New Jersey','Cherry Hill')
INSERT INTO DimLocation  VALUES (120, 'USA', 'Rhode Island', 'Warwick')
go
INSERT INTO DimLocation  VALUES	(121,	'USA',	'Florida',	'Alachua city')
INSERT INTO DimLocation  VALUES	(122	, 'USA'	,'Florida'	,'Archer city')
INSERT INTO DimLocation  VALUES	(123	,'USA',	'Florida',	'Gainesville city')
INSERT INTO DimLocation  VALUES	(124	, 'USA'	,'Florida','Hawthorne city')
INSERT INTO DimLocation  VALUES	(125 , 'USA',	'Florida',	'High Springs city')
INSERT INTO DimLocation  VALUES (126,	'USA',	'Florida',	'La Crosse town')
INSERT INTO DimLocation  VALUES	(127,	'USA'	,'Florida',	'Micanopy town')
INSERT INTO DimLocation  VALUES (128,	'USA',	'Florida',	'Newberry city')
INSERT INTO DimLocation  VALUES	(129,	'USA',	'Florida',	'Waldo city')
INSERT INTO DimLocation  VALUES	(130	,'USA'	,'Florida'	,'Punta Gorda city')	

INSERT INTO DimLocation  VALUES	(131,	'USA',	'Florida',	'Balance of Alachua County')
INSERT INTO DimLocation  VALUES	(132,	'USA',	'Florida',	'Glen St. Mary town')
INSERT INTO DimLocation  VALUES	(133,	'USA',	'Florida',	'Macclenny city')
INSERT INTO DimLocation  VALUES	(134,	'USA',	'Florida',	'Balance of Baker County')
INSERT INTO DimLocation  VALUES	(135,	'USA',	'Florida',	'Callaway city')
INSERT INTO DimLocation  VALUES	(136,	'USA',	'Florida',	'Lynn Haven city')
INSERT INTO DimLocation  VALUES	(137,	'USA',	'Florida',	'Mexico Beach city')
INSERT INTO DimLocation  VALUES	(138,	'USA',	'Florida',	'Panama City city')
INSERT INTO DimLocation  VALUES	(139,	'USA',	'Florida',	'Panama City Beach city')
INSERT INTO DimLocation  VALUES	(140,	'USA',	'Florida',	'Parker city')

INSERT INTO DimLocation  VALUES	(141,	'USA'	,'Florida'	,'Springfield city')
INSERT INTO DimLocation  VALUES	(142	,'USA','Florida','Balance of Bay County')
INSERT INTO DimLocation  VALUES	(143	,'USA'	,'Florida','Brooker town')
INSERT INTO DimLocation  VALUES	(144	,'USA'	,'Florida'	,'Hampton city')
INSERT INTO DimLocation  VALUES	(145	,'USA'	,'Florida'	,'Lawtey city')
INSERT INTO DimLocation  VALUES	(146	,'USA'	,'Florida','Starke city')
INSERT INTO DimLocation  VALUES	(147	,'USA'	,'Florida','Balance of Bradford')
INSERT INTO DimLocation  VALUES	(148	,'USA'	,'Florida','Cape Canaveral city')
INSERT INTO DimLocation  VALUES	(149	,'USA'	,'Florida',	'Cocoa city')
INSERT INTO DimLocation  VALUES	(150	,'USA'	,'Florida'	,'Cocoa Beach city')

INSERT INTO DimLocation  VALUES	(151	,'USA'	,'Florida'	,'Grant-Valkaria town')
INSERT INTO DimLocation  VALUES	(152	,'USA'	,'Florida'	,'Indialantic town')
INSERT INTO DimLocation  VALUES	(153	,'USA'	,'Florida'	,'IndianHarbourBeach')
INSERT INTO DimLocation  VALUES	(154	,'USA'	,'Florida','Malabar town')
INSERT INTO DimLocation  VALUES	(155	,'USA'	,'Florida'	,'Melbourne city')
INSERT INTO DimLocation  VALUES	(156	,'USA'	,'Florida'	,'Melbourne Beach')
INSERT INTO DimLocation  VALUES	(157	,'USA'	,'Florida'	,'Melbourne Village')
INSERT INTO DimLocation  VALUES	(158	,'USA'	,'Florida'	,'Palm Bay city')
INSERT INTO DimLocation  VALUES	(159	,'USA'	,'Florida','Palm Shores town')
INSERT INTO DimLocation  VALUES	(160	,'USA'	,'Florida','Rockledge city')

INSERT INTO DimLocation  VALUES	(161	,'USA'	,'Florida'	,'Satellite Beach city')
INSERT INTO DimLocation  VALUES	(162	,'USA'	,'Florida'	,'Titusville city')
INSERT INTO DimLocation  VALUES	(163	,'USA'	,'Florida'	,'West Melbourne city')
INSERT INTO DimLocation  VALUES	(164	,'USA'	,'Florida'	,'Balance of Brevard County')
INSERT INTO DimLocation  VALUES	(165	,'USA'	,'Florida'	,'Coconut Creek city')
INSERT INTO DimLocation  VALUES	(166	,'USA'	,'Florida'	,'Cooper City city')
INSERT INTO DimLocation  VALUES	(167	,'USA'	,'Florida'	,'Coral Springs city')
INSERT INTO DimLocation  VALUES	(168	,'USA'	,'Florida'	,'Dania Beach city')
INSERT INTO DimLocation  VALUES	(169	,'USA'	,'Florida'	,'Davie town')

INSERT INTO DimLocation  VALUES	(170	,'USA'	,'Florida'	,'Deerfield Beach')
INSERT INTO DimLocation  VALUES	(171	,'USA'	,'Florida'	,'Fort Lauderdale')
INSERT INTO DimLocation  VALUES	(172	,'USA'	,'Florida'	,'Hallandale Beach')
INSERT INTO DimLocation  VALUES	(173	,'USA'	,'Florida'	,'Hillsboro Beach')
INSERT INTO DimLocation  VALUES	(174	,'USA'	,'Florida'	,'Hollywood')
INSERT INTO DimLocation  VALUES	(175	,'USA'	,'Florida'	,'Lauderdale-by-the-Sea town')						
INSERT INTO DimLocation  VALUES	(176	,'USA'	,'Florida'	,'Lauderdale Lakes C')						
INSERT INTO DimLocation  VALUES	(177	,'USA'	,'Florida'	,'Lauderhill C')						
INSERT INTO DimLocation  VALUES	(178	,'USA'	,'Florida'	,'Lazy Lake V')						
INSERT INTO DimLocation  VALUES	(179	,'USA'	,'Florida'	,'Lighthouse Point')						
INSERT INTO DimLocation  VALUES	(180	,'USA'	,'Florida'	,'Margate city')
						
INSERT INTO DimLocation  VALUES	(181	,'USA'	,'Florida'	,'Miramar city')						
INSERT INTO DimLocation  VALUES	(182	,'USA'	,'Florida'	,'North Lauderdale')						
INSERT INTO DimLocation  VALUES	(183	,'USA'	,'Florida'	,'Oakland Park city')						
INSERT INTO DimLocation  VALUES	(184	,'USA'	,'Florida'	,'Parkland city')
INSERT INTO DimLocation  VALUES	(185	,'USA'	,'Florida'	,'Pembroke Park')						
INSERT INTO DimLocation  VALUES	(186	,'USA'	,'Florida'	,'Pembroke Pines')						
INSERT INTO DimLocation  VALUES	(187	,'USA'	,'Florida'	,'Plantation')						
INSERT INTO DimLocation  VALUES	(188	,'USA'	,'Florida'	,'Pompano Beach')						
INSERT INTO DimLocation  VALUES	(189	,'USA'	,'Florida'	,'Sea Ranch Lakes')						
INSERT INTO DimLocation  VALUES	(190	,'USA'	,'Florida'	,'Southwest Ranches')	
					
INSERT INTO DimLocation  VALUES	(191	,'USA'	,'Florida'	,'Sunrise city')						
INSERT INTO DimLocation  VALUES	(192	,'USA'	,'Florida'	,'Tamarac city')						
INSERT INTO DimLocation  VALUES (193	,'USA'	,'Florida'	,'Weston city')						
INSERT INTO DimLocation  VALUES	(194	,'USA'	,'Florida'	,'West Park city')						
INSERT INTO DimLocation  VALUES	(195	,'USA'	,'Florida'	,'Wilton Manors city')						
INSERT INTO DimLocation  VALUES	(196	,'USA'	,'Florida'	,'Balance of Broward County')						
INSERT INTO DimLocation  VALUES	(197	,'USA'	,'Florida'	,'Altha town')						
INSERT INTO DimLocation  VALUES	(198	,'USA'	,'Florida'	,'Blountstown city')						
INSERT INTO DimLocation  VALUES	(199	,'USA'	,'Florida'	,'Balance of Calhoun County')						
INSERT INTO DimLocation  VALUES	(200	,'USA'	,'Florida'	,'Crystal River city')
go

select *  from DimLocation
go

--Create Time Table
Create table DimTime
(
		  DateKey    int primary key,
		  FullDate   datetime ,
		  YearNo     int,
		  SemNo		Tinyint,
		  QtrNo      Tinyint,
		  MonthNo    Tinyint,
		  WeekNo     Tinyint,
		  DayNo      Tinyint,
		  EngMonthName Varchar(10),
		  TelMonthName  Varchar(20)
)
go

select * from DimTime
go

--exec GenerateDimTime
go

--Fact Table
create table FactSales
(
	ProductKey		int		not null foreign key references DimProduct(ProductKey),
	CustomerKey		int		not null foreign key references DimCustomer(CustomerKey),
	SaleDateKey		int		not null foreign key references DimTime(DateKey),
	QtySold			int		not null ,
	SalesAmount		money	not null ,
	DeliveryDateKey	int		not null	foreign key references DimTime(DateKey),
	LocationKey		int		not null	foreign key references DimLocation(LocationKey)
)
go

--Get all tables
use AmazonDW
go

select name from sys.tables
go

select 'SELECT * FROM '+ name from sys.tables
go

SELECT * FROM DimProduct -- SSIS Pkg
SELECT * FROM DimCustomer --SSIS Pkg

SELECT * FROM FactSales

--data
SELECT * FROM DimLocation
SELECT * FROM DimTime


select * from Amazon_SSIS_Logs
go

--insert into Amazon_SSIS_Logs values (?, getdate(), ?,?, 'Loading to DWH', ?)

